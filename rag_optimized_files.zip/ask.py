import time

import ollama

from config import (
    LLM_MODEL,
    ANSWER_NUM_PREDICT,
    OLLAMA_KEEP_ALIVE,
    DEBUG_RETRIEVAL,
)
from retrieval import HybridRetriever


def print_question_analysis(search_output):
    analysis = search_output["analysis"]

    print("\nQUESTION ANALYSIS")
    print("=================")

    print(
        "Entities:",
        analysis["entities"]
    )

    print(
        "Intent:",
        analysis["intent"]
    )

    print(
        "Keywords:",
        analysis["keywords"]
    )

    print(
        "Expanded search:",
        search_output["search_text"]
    )


def print_vector_ranking(results):
    print("\nVECTOR RANKING")
    print("==============")

    for result in results[:10]:
        metadata = result["metadata"]

        print(
            f"\nRank: "
            f"{result['vector_rank']}"
        )

        print(
            f"Distance: "
            f"{result['vector_distance']:.4f}"
        )

        print(
            f"Document: "
            f"{metadata.get('source')}"
        )

        print(
            f"Section: "
            f"{metadata.get('section_id')} - "
            f"{metadata.get('section_title')}"
        )

        print(
            result["document"][:350]
        )


def print_bm25_ranking(results):
    print("\nBM25 RANKING")
    print("============")

    for result in results[:10]:
        metadata = result["metadata"]

        print(
            f"\nRank: "
            f"{result['bm25_rank']}"
        )

        print(
            f"Score: "
            f"{result['bm25_score']:.4f}"
        )

        print(
            f"Document: "
            f"{metadata.get('source')}"
        )

        print(
            f"Section: "
            f"{metadata.get('section_id')} - "
            f"{metadata.get('section_title')}"
        )

        print(
            result["document"][:350]
        )


def print_final_ranking(results):
    print("\nFINAL RANKING")
    print("=============")

    for rank, result in enumerate(
        results,
        start=1
    ):
        metadata = result["metadata"]

        print(f"\nFinal rank: {rank}")

        print(
            f"Document: "
            f"{metadata.get('source')}"
        )

        print(
            f"Section: "
            f"{metadata.get('section_id')} - "
            f"{metadata.get('section_title')}"
        )

        print(
            f"Vector rank: "
            f"{result.get('vector_rank')}"
        )

        print(
            f"BM25 rank: "
            f"{result.get('bm25_rank')}"
        )

        print(
            f"RRF score: "
            f"{result.get('rrf_score', 0):.6f}"
        )

        print(
            f"Metadata score: "
            f"{result.get('metadata_score', 0):.6f}"
        )

        print(
            f"Reranker relevance: "
            f"{result.get('reranker_relevance')}"
        )

        print(
            f"Reranker reason: "
            f"{result.get('reranker_reason', '')}"
        )

        print(result["document"][:700])


def generate_answer(
    question,
    retrieved_results
):
    context_sections = []

    for source_number, result in enumerate(
        retrieved_results,
        start=1
    ):
        metadata = result["metadata"]

        context_sections.append(
            f"""
[SOURCE {source_number}]
Document: {metadata.get("source", "Unknown")}
Document type: {metadata.get("document_type", "Unknown")}
Section ID: {metadata.get("section_id", "Unknown")}
Section title: {metadata.get("section_title", "Unknown")}

Content:
{result["document"]}
""".strip()
        )

    context = "\n\n---\n\n".join(
        context_sections
    )

    prompt = f"""
You are an engineering knowledge assistant.

Answer the question using only the supplied sources.

Rules:
1. Identify the exact component, service, feature or
   property requested by the user.
2. Do not mix information from similarly named but
   different components.
3. Prefer the source whose section title most directly
   matches the question.
4. Do not use outside knowledge.
5. Preserve technical names, property names, requirement
   IDs and default values exactly.
6. Cite factual statements using [SOURCE 1],
   [SOURCE 2], and so on.
7. If the supplied sources do not contain the answer,
   respond exactly:
   Information not found in the available documents.
8. Give a concise technical explanation.

Question:
{question}

Sources:
{context}

Answer:
""".strip()

    print(
        f"Prompt size: {len(prompt):,} characters | "
        f"retrieved context: {len(context):,} characters"
    )

    response = ollama.chat(
        model=LLM_MODEL,
        messages=[
            {
                "role": "user",
                "content": prompt
            }
        ],
        options={
            "temperature": 0,
            "num_predict": ANSWER_NUM_PREDICT,
        },
        keep_alive=OLLAMA_KEEP_ALIVE,
    )

    # Ollama reports model timings in nanoseconds. Keep this diagnostic
    # separate from wall-clock time so model load, prompt processing and
    # token generation can be compared.
    print("\nANSWER GENERATION TIMING")
    print("========================")
    for key, label in (
        ("total_duration", "Ollama total"),
        ("load_duration", "Model load"),
        ("prompt_eval_duration", "Prompt processing"),
        ("eval_duration", "Token generation"),
    ):
        value = response.get(key) if isinstance(response, dict) else getattr(response, key, None)
        if isinstance(value, (int, float)):
            print(f"{label}: {value / 1_000_000_000:.3f}s")
    for key, label in (("prompt_eval_count", "Prompt tokens"), ("eval_count", "Generated tokens")):
        value = response.get(key) if isinstance(response, dict) else getattr(response, key, None)
        if isinstance(value, (int, float)):
            print(f"{label}: {int(value)}")

    return response["message"]["content"]


def main():
    print("Loading hybrid retrieval system...")

    retriever = HybridRetriever()

    print(
        f"Loaded chunks: "
        f"{len(retriever.records)}"
    )

    while True:
        question = input(
            "\nAsk a question, or type exit: "
        ).strip()

        if question.lower() == "exit":
            break

        if not question:
            continue

        question_started_at = time.perf_counter()
        search_output = retriever.search(question)
        retrieval_elapsed = time.perf_counter() - question_started_at

        if DEBUG_RETRIEVAL:
            print_question_analysis(search_output)
            print_vector_ranking(search_output["vector_results"])
            print_bm25_ranking(search_output["bm25_results"])
            print_final_ranking(search_output["final_results"])

        print("\nRETRIEVAL TIMING")
        print("================")
        for stage, seconds in search_output.get("timings", {}).items():
            print(f"{stage}: {seconds:.3f}s")
        print(f"retrieval wall-clock: {retrieval_elapsed:.3f}s")
        print(f"context chunks: {len(search_output['final_results'])}")

        answer_started_at = time.perf_counter()
        answer = generate_answer(
            question=question,
            retrieved_results=search_output["final_results"]
        )
        answer_elapsed = time.perf_counter() - answer_started_at

        print("\nANSWER")
        print("======")
        print(answer)
        print(f"\nAnswer wall-clock: {answer_elapsed:.3f}s")
        print(f"Total question time: {time.perf_counter() - question_started_at:.3f}s")


if __name__ == "__main__":
    main()
