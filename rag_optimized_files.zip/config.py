from pathlib import Path


BASE_DIR = Path(__file__).resolve().parent

DOCUMENT_DIRECTORY = BASE_DIR / "documents"
CHROMA_DIRECTORY = BASE_DIR / "chroma_db"

COLLECTION_NAME = "engineering_knowledge"

EMBEDDING_MODEL = "nomic-embed-text"
LLM_MODEL = "gemma3"

# Chunking configuration
MAX_CHUNK_CHARACTERS = 2500
CHUNK_OVERLAP_BLOCKS = 1

# Retrieval configuration
VECTOR_CANDIDATES = 20
BM25_CANDIDATES = 20
FUSED_CANDIDATES = 12
RERANK_CANDIDATES = 8
FINAL_CONTEXT_CHUNKS = 3

# Reciprocal Rank Fusion configuration
RRF_CONSTANT = 60
VECTOR_WEIGHT = 0.55
BM25_WEIGHT = 0.45


# Performance and diagnostics
# These two extra LLM calls are disabled by default because they can
# multiply latency on a local model. Enable them only if your test set
# shows a meaningful retrieval-quality improvement.
ENABLE_LLM_QUERY_ANALYSIS = False
ENABLE_LLM_RERANKING = False
DEBUG_RETRIEVAL = False

# Keep answer generation bounded on local hardware. Raise to 384 if answers
# are being cut off; lower to 160 for shorter answers.
ANSWER_NUM_PREDICT = 256
OLLAMA_KEEP_ALIVE = "10m"

# Keep the final prompt small. Increase to 4 if your evaluation questions
# show that three chunks omit necessary evidence.
RERANK_CONTENT_LIMIT = 1600
