from pathlib import Path


BASE_DIR = Path(__file__).resolve().parent

DOCUMENT_DIRECTORY = BASE_DIR / "documents"
CHROMA_DIRECTORY = BASE_DIR / "chroma_db"

COLLECTION_NAME = "engineering_knowledge"

EMBEDDING_MODEL = "nomic-embed-text"
LLM_MODEL = "gemma3"

# Chunking configuration
MAX_CHUNK_CHARACTERS = 2500
CHUNK_OVERLAP_BLOCKS = 1

# Retrieval configuration
VECTOR_CANDIDATES = 20
BM25_CANDIDATES = 20
FUSED_CANDIDATES = 12
RERANK_CANDIDATES = 8
FINAL_CONTEXT_CHUNKS = 4

# Agentic retrieval controls
MAX_AGENT_SEARCH_QUERIES = 3
ENABLE_LLM_QUERY_ANALYSIS = True
ENABLE_LLM_RERANKING = False  # Avoid very slow local reranking by default
ANSWER_NUM_PREDICT = 384
OLLAMA_KEEP_ALIVE = "10m"

# Reciprocal Rank Fusion configuration
RRF_CONSTANT = 60
VECTOR_WEIGHT = 0.55
BM25_WEIGHT = 0.45

# Agentic fallback controls
MAX_AGENT_FOLLOWUP_QUERIES = 2
AGENT_MIN_RELEVANCE = 0.18
