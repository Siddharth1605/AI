# Lost Knowledge — Agentic RAG v1

This version adds a **bounded retrieval-recovery agent** around the existing hybrid RAG pipeline.
It keeps the current document ingestion and retrieval approach: document chunks, `nomic-embed-text`, ChromaDB vector search, BM25 keyword search, reciprocal rank fusion (RRF), metadata ranking, and Gemma 3 through Ollama.

## What the agent does

1. Runs the existing RAG search, including its initial query analysis and hybrid retrieval.
2. Uses a cheap lexical/title-overlap check to decide whether the initial results may be weak.
3. Only when the evidence looks weak, asks Gemma 3 to assess the retrieved excerpts and propose up to two follow-up search queries.
4. Runs those follow-up searches through the same hybrid retriever (without invoking another query-planning LLM call for each query).
5. Merges duplicate chunks and keeps chunks that rank consistently across searches.
6. Passes the final context to the existing grounded answer-generation prompt.

This is a bounded agent loop, not a multi-agent system. It does not execute shell commands, change files, or modify production systems.

## Requirements

- Python 3.10+
- Ollama running locally
- Models pulled in Ollama:
  - `ollama pull gemma3`
  - `ollama pull nomic-embed-text`

Install Python packages:

```bash
pip install -r requirements.txt
```

## Folder layout

Place your documents in `documents/`. The first ingestion run creates `chroma_db/`.

```text
lost_knowledge_agentic_v1/
  documents/       # your source documents (create this folder)
  chroma_db/       # generated index (created by ingestion)
  config.py
  documentreader.py
  ingest.py
  retrieval.py
  agent.py
  ask.py
```

## Run

1. Copy your existing `documents/` directory and `chroma_db/` directory into this project folder if you want to reuse your existing index. Keep a backup of the current project first.
2. If you are building a new index, put source documents into `documents/` and run:

   ```bash
   python ingest.py
   ```

3. Start the Q&A loop:

   ```bash
   python ask.py
   ```

## Important behavior

- The agent only attempts fallback retrieval when the first search looks weak.
- It makes at most two follow-up searches.
- If the agent planner fails or returns no useful query, the original RAG results are retained.
- Extra LLM calls can increase latency; measure both answer quality and end-to-end time before deciding whether to keep the agent enabled for every use case.
- The relevance threshold is a heuristic, not a calibrated confidence score. Review the printed decision and test with known-answer questions.
- This code has been syntax-checked, but must be tested against your local Ollama models and actual ChromaDB index before relying on its answers.
