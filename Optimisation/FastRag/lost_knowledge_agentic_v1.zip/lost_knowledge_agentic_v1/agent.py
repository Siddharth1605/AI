"""Bounded agentic fallback over the existing hybrid RAG pipeline.

The agent does not replace ChromaDB, BM25, RRF, metadata ranking, or answer
 generation. It checks initial retrieval using a lightweight heuristic; only if
the evidence looks weak does it ask the LLM for targeted follow-up queries.
"""
from __future__ import annotations

import json
import time
from copy import deepcopy

import ollama

from config import AGENT_MIN_RELEVANCE, MAX_AGENT_FOLLOWUP_QUERIES, LLM_MODEL
from retrieval import RRF_CONSTANT, token_overlap


def assess_initial_evidence(question: str, search_output: dict) -> dict:
    """Cheap first-pass evidence check; does not require an extra LLM call."""
    results = search_output.get("final_results") or []
    if not results:
        return {"weak": True, "score": 0.0, "reason": "No chunks were retrieved."}

    best_score = 0.0
    for result in results[:4]:
        metadata = result.get("metadata") or {}
        title = str(metadata.get("section_title", ""))
        source = str(metadata.get("source", ""))
        body = str(result.get("document", ""))[:2500]
        score = (
            0.55 * token_overlap(question, title)
            + 0.10 * token_overlap(question, source)
            + 0.35 * token_overlap(question, body)
        )
        best_score = max(best_score, score)

    weak = best_score < AGENT_MIN_RELEVANCE
    reason = (
        f"Initial evidence overlap score is low ({best_score:.2f})."
        if weak else
        f"Initial evidence overlap score is acceptable ({best_score:.2f})."
    )
    return {"weak": weak, "score": best_score, "reason": reason}


def _plan_followup_queries(question: str, search_output: dict) -> dict:
    """Ask the local LLM to assess evidence and suggest bounded follow-up searches."""
    source_blocks = []
    for i, result in enumerate((search_output.get("final_results") or [])[:4], start=1):
        metadata = result.get("metadata") or {}
        source_blocks.append(
            f"[RESULT {i}] Source: {metadata.get('source', 'Unknown')}\n"
            f"Section: {metadata.get('section_title', 'Unknown')}\n"
            f"Excerpt: {str(result.get('document', ''))[:900]}"
        )
    context = "\n\n---\n\n".join(source_blocks) or "No results retrieved."
    prompt = f"""
You are a retrieval-recovery planner for an engineering-document retrieval system.
You are NOT answering the user's question. Inspect the excerpts and propose
follow-up searches only if they do not contain enough direct, relevant evidence.

Rules:
- Preserve exact service names, class names, error codes, configuration keys and IDs.
- Do not invent entities or assume a cause.
- Return at most {MAX_AGENT_FOLLOWUP_QUERIES} short, distinct search queries.
- Search for alternate wording, related technical terms, or a missing subtopic.
- If the current excerpts are sufficient, set sufficient=true and queries=[].
- Return valid JSON only.

Question: {question}

Retrieved evidence:
{context}

Return exactly this JSON structure:
{{"sufficient": false, "reason": "short explanation", "queries": ["query 1"]}}
""".strip()
    try:
        response = ollama.chat(
            model=LLM_MODEL,
            messages=[{"role": "user", "content": prompt}],
            format="json",
            options={"temperature": 0},
        )
        data = json.loads(response["message"]["content"])
        queries = data.get("queries", [])
        if not isinstance(queries, list):
            queries = []
        queries = [str(q).strip() for q in queries if str(q).strip()]

        unique = []
        original = question.casefold().strip()
        for query in queries:
            if query.casefold() != original and query.casefold() not in {q.casefold() for q in unique}:
                unique.append(query)
            if len(unique) >= MAX_AGENT_FOLLOWUP_QUERIES:
                break

        sufficient = bool(data.get("sufficient", False))
        if sufficient:
            unique = []
        return {
            "sufficient": sufficient,
            "reason": str(data.get("reason", "Agent assessed initial evidence."))[:400],
            "queries": unique,
        }
    except Exception as exc:
        # Safe fallback: no guessed queries; retain the original RAG result.
        return {
            "sufficient": False,
            "reason": f"Agent planning failed; keeping original results ({type(exc).__name__}).",
            "queries": [],
        }


def _merge_result_sets(result_sets: list[tuple[str, list[dict]]], limit: int) -> list[dict]:
    """Merge chunks from multiple searches using rank-based reciprocal fusion."""
    merged = {}
    for query, results in result_sets:
        seen_this_query = set()
        for rank, result in enumerate(results, start=1):
            result_id = result.get("id")
            if result_id is None or result_id in seen_this_query:
                continue
            seen_this_query.add(result_id)
            if result_id not in merged:
                merged[result_id] = deepcopy(result)
                merged[result_id]["agent_merge_score"] = 0.0
                merged[result_id]["matched_queries"] = []
            merged[result_id]["agent_merge_score"] += 1.0 / (RRF_CONSTANT + rank)
            merged[result_id]["matched_queries"].append(query)
    return sorted(
        merged.values(),
        key=lambda item: item.get("agent_merge_score", 0.0),
        reverse=True,
    )[:limit]


def agentic_search(retriever, question: str) -> dict:
    """Run baseline RAG, then invoke bounded recovery only for weak evidence."""
    started = time.perf_counter()
    search_output = retriever.search(question, plan_queries=True)
    decision = assess_initial_evidence(question, search_output)
    search_output["agent"] = {
        "triggered": False,
        "retried": False,
        "reason": decision["reason"],
        "initial_relevance_score": round(decision["score"], 4),
        "followup_queries": [],
    }

    if not decision["weak"]:
        search_output.setdefault("timings", {})["agent_total"] = time.perf_counter() - started
        return search_output

    search_output["agent"]["triggered"] = True
    planner = _plan_followup_queries(question, search_output)
    search_output["agent"]["reason"] = planner["reason"]
    queries = planner["queries"] if not planner["sufficient"] else []
    search_output["agent"]["followup_queries"] = queries

    if not queries:
        search_output.setdefault("timings", {})["agent_total"] = time.perf_counter() - started
        return search_output

    result_sets = [(question, search_output.get("final_results", []))]
    followup_outputs = []
    for query in queries[:MAX_AGENT_FOLLOWUP_QUERIES]:
        # Single-query mode avoids another LLM query-planning call per retry.
        extra = retriever.search(query, plan_queries=False)
        followup_outputs.append(extra)
        result_sets.append((query, extra.get("final_results", [])))

    merged = _merge_result_sets(result_sets, limit=4)
    if merged:
        search_output["final_results"] = merged
    search_output["agent"]["retried"] = bool(followup_outputs)
    search_output["agent"]["followup_search_count"] = len(followup_outputs)
    search_output["agent"]["additional_results"] = sum(
        len(output.get("final_results", [])) for output in followup_outputs
    )
    search_output.setdefault("timings", {})["agent_total"] = time.perf_counter() - started
    return search_output
