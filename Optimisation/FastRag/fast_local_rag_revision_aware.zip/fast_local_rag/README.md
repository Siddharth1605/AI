# Fast Local Engineering RAG

A clean baseline for local Ollama: DOCX/TXT/MD/LOG/CSV ingestion, ChromaDB semantic retrieval, BM25 keyword retrieval, reciprocal-rank fusion, then one grounded answer-generation call. No agent calls or LLM reranker by default.

## Windows setup

1. Install Ollama and make sure these are available:
   ```powershell
   ollama list
   ollama pull nomic-embed-text
   ```
2. Copy a subset of your documents into `documents\` first. Supported formats: `.docx`, `.txt`, `.md`, `.log`, `.csv`. This starter skips PDFs and old `.doc` files.
3. In this folder:
   ```powershell
   py -m venv .venv
   .\.venv\Scripts\Activate.ps1
   pip install -r requirements.txt
   python document_ingest.py
   python ask.py
   ```

## Important safety note

This uses a separate collection named `engineering_knowledge_v2` and does not overwrite your existing collection. Back up documents and database before experimenting. The script creates embeddings at ingestion time; ingesting 130 MB can take a while, but that is a one-time cost.

## Model

`gemma3:latest` currently resolves to the Gemma 3 4B Q4_K_M variant in the Ollama library, but `latest` can change over time. For reproducible benchmarking, record `ollama list` output and pin `gemma3:4b` in `config.py` or the `RAG_CHAT_MODEL` environment variable.

## Performance and accuracy

The target is under 60 seconds, not a guarantee. We keep only five retrieved chunks and cap context size to avoid processing the whole corpus on every question. The best next optimization depends on the timings printed by `ask.py`.

Create 20–30 questions with known answers. Score factual correctness, whether the correct source was retrieved, unsupported claims, and total time. Do not evaluate performance on only one question.

## Limitations

- Ingestion parser currently supports DOCX/TXT/MD/LOG/CSV only.
- BM25 index is rebuilt in memory at startup. If you have many tens of thousands of chunks, we should persist or replace this component.
- Citations identify file and chunk, not exact page/paragraph.


## Flask chatbot UI

This adds a small local Flask web UI while keeping the existing `retrieval.py`, `config.py`, and `document_ingest.py` logic unchanged. The UI calls the same hybrid retrieval and one Ollama answer-generation call as `ask.py`.

1. Make sure Ollama is running and the configured chat/embedding models are available.
2. Ensure this project folder contains the existing `chroma_db` and `documents` folders, or set `RAG_CHROMA_DIR` and `RAG_DOCUMENTS_DIR` to their locations. The Chroma collection must match `COLLECTION_NAME` in `config.py`.
3. Activate your existing virtual environment, then install dependencies:
   ```powershell
   pip install -r requirements.txt
   ```
4. Start the web app:
   ```powershell
   python app.py
   ```
5. Open `http://127.0.0.1:5000` in your browser.

`ask.py` remains available as the terminal baseline. The Flask app loads the retriever once at startup/on first request and reuses it for subsequent questions. The web page displays retrieved source names and timing metrics. This development server binds to localhost; do not expose it publicly without proper authentication, production serving, and security review.


## Revision-aware retrieval (without re-ingestion)

This version enhances retrieval without modifying `document_ingest.py` or rebuilding the Chroma collection.
At retriever startup, `document_metadata.py` reads the first table in each DOCX under `documents/` and looks
for `Reviewed By`, `Author`, and `Date`/review-date fields. It caches lightweight metadata in
`.document_metadata_cache.json`; only files whose size or modification timestamp changes are reparsed.
This is metadata extraction only: it does not call Ollama embeddings or rewrite Chroma records.

Retrieval changes:

- Pulls a wider vector candidate pool, then suppresses duplicate passages so repeated SRS copies do not crowd out distinct evidence.
- De-duplicates exact copies in BM25 candidate ranking.
- When two near-identical passages have different, parseable review dates, prefers the newer reviewed copy for ordinary questions.
- Retains revision differences for explicit history/comparison questions.
- Limits the number of chunks from a single source in the final context and passes revision metadata to the answer model and source list.
- Strengthens grounding instructions: if conflicting evidence cannot be resolved from revision metadata, the assistant must state that uncertainty rather than silently combining values.

Important: review dates are freshness signals, not a guaranteed document lifecycle status. If the review table is missing or its date cannot be parsed, the app does not pretend to know which version is current. For reliable current-vs-superseded status across substantially renamed SRS documents, a maintained document-family identifier or authoritative ALM revision/status is still the best long-term source.

## LAN access

The Flask app binds to `0.0.0.0:5000` by default so other machines on the same trusted LAN can open `http://<server-ip>:5000`. Find the server IPv4 address with `ipconfig` on Windows. If it cannot be reached, add a Windows Firewall inbound rule for TCP 5000 restricted to the appropriate Private network/profile. Do not expose this development server directly to the public internet. You can override the bind settings with `RAG_HOST` and `RAG_PORT` environment variables.

## Upgrade steps

1. Stop the old Flask app.
2. Extract this ZIP into a new folder, or back up your current folder before replacing application files.
3. Copy your existing `documents/` and `chroma_db/` directories into the new project (or point `RAG_DOCUMENTS_DIR` and `RAG_CHROMA_DIR` at them).
4. Install any newly required packages with `pip install -r requirements.txt`.
5. Run `python app.py`. **Do not run `python document_ingest.py` for this upgrade.**

The existing `document_ingest.py` is intentionally preserved byte-for-byte.
