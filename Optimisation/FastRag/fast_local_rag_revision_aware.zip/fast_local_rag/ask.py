import time
import requests
from config import OLLAMA_URL, CHAT_MODEL, MAX_NEW_TOKENS, OLLAMA_KEEP_ALIVE
from retrieval import HybridRetriever

SYSTEM = '''You are an engineering knowledge assistant. Answer only from the supplied evidence passages.
Cite every material factual claim using [Source: relative/path, chunk N]. Never invent configuration
values, steps, owners, dates, or behavior. If the evidence does not support an answer, say exactly:
"I couldn't find enough evidence in the indexed documents."

Each passage may include document metadata such as title, Reviewed By, Author, and Review Date.
For ordinary questions, prefer the newest reviewed passage when it is clearly a revision of the same
requirement or document. A newer date is a freshness signal, not proof that unrelated documents are
superseded. Do not combine conflicting values from different revisions as if both are current. If
revision identity is unclear or relevant passages conflict, state the conflict, cite both sources, and
say the documents do not establish which one is authoritative. For explicit history/comparison
questions, preserve the differences between versions instead of suppressing older evidence.
Keep answers concise and specific; do not add generic background that is not in the evidence.'''

def answer(question, retriever):
    start = time.perf_counter()
    retrieved = retriever.search(question)
    retrieval_end = time.perf_counter()
    passages = []
    for n, item in enumerate(retrieved['results'], 1):
        meta = item['meta']
        revision = []
        for key, label in (("title", "Title"), ("review_date", "Review Date"), ("reviewed_by", "Reviewed By"), ("author", "Author")):
            if meta.get(key):
                revision.append(f"{label}: {meta[key]}")
        revision_text = (" | " + " | ".join(revision)) if revision else ""
        passages.append(f"[PASSAGE {n} | Source: {meta.get('source', 'unknown')} | chunk {meta.get('chunk', '?')}{revision_text}]\n{item['text']}")
    context = '\n\n---\n\n'.join(passages)
    prompt = f'Question:\n{question}\n\nEvidence passages:\n{context}\n\nAnswer from this evidence only and cite sources.'
    response = requests.post(f'{OLLAMA_URL}/api/chat', json={
        'model': CHAT_MODEL,
        'stream': False,
        'keep_alive': OLLAMA_KEEP_ALIVE,
        'messages': [{'role': 'system', 'content': SYSTEM}, {'role': 'user', 'content': prompt}],
        'options': {'num_predict': MAX_NEW_TOKENS, 'temperature': 0.1},
    }, timeout=180)
    response.raise_for_status()
    payload = response.json()
    end = time.perf_counter()
    print('\n' + '=' * 72)
    print(payload.get('message', {}).get('content', '').strip())
    print('=' * 72)
    print(f"Retrieved {len(retrieved['results'])} passages from {retrieved['candidate_count']} fused candidates")
    print('Retrieval timings:', {k: round(v, 3) for k, v in retrieved['timings'].items()})
    print(f'LLM generation: {end - retrieval_end:.2f}s | Total: {end - start:.2f}s')
    print('Sources used:')
    for item in retrieved['results']:
        print(f" - {item['meta'].get('source')} (chunk {item['meta'].get('chunk')})")
    stats = payload.get('eval_count'), payload.get('prompt_eval_count')
    if any(stats): print(f'LLM tokens: generated={stats[0]}, prompt={stats[1]}')
    return payload

def main():
    try:
        retriever = HybridRetriever()
    except Exception as exc:
        raise SystemExit(f'Could not open collection. Run `python document_ingest.py` first. Details: {exc}')
    print(f"Ready. Collection has {retriever.collection.count()} chunks. Model: {CHAT_MODEL}")
    print("Ask a question, or type 'exit'.")
    while True:
        q = input('\nQuestion> ').strip()
        if q.lower() in {'exit', 'quit'}: break
        if q:
            try: answer(q, retriever)
            except Exception as exc: print('Request failed:', exc)

if __name__ == '__main__':
    main()
