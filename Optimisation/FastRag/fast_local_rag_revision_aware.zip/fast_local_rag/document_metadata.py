"""Read lightweight DOCX revision metadata at runtime; does not rebuild Chroma embeddings."""
from __future__ import annotations

import json
import re
from datetime import datetime
from pathlib import Path
from typing import Any

from docx import Document

from config import BASE_DIR, DOCUMENTS_DIR

CACHE_PATH = BASE_DIR / ".document_metadata_cache.json"
SUPPORTED_DOCX = {".docx"}

_LABELS = {
    "reviewed_by": {"reviewed by", "reviewer", "reviewedby", "reviewed by name"},
    "author": {"author", "document author", "prepared by", "created by", "owner"},
    "review_date": {"date", "review date", "reviewed date", "date reviewed", "revision date", "last reviewed", "reviewed on"},
    "title": {"title", "document title", "srs title", "document name", "requirement title"},
}
_DATE_FORMATS = (
    "%Y-%m-%d", "%Y/%m/%d", "%d/%m/%Y", "%m/%d/%Y", "%d-%m-%Y", "%d.%m.%Y",
    "%d-%b-%Y", "%d %b %Y", "%d %B %Y", "%b %d, %Y", "%B %d, %Y",
    "%Y-%m-%d %H:%M:%S", "%d/%m/%y", "%d-%m-%y",
)


def _clean(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip().strip(":")


def _label_key(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", _clean(value).lower()).strip()


def _parse_date(value: str) -> str | None:
    value = _clean(value)
    if not value:
        return None
    # Dates embedded in values such as "Reviewed on: 22-Oct-2026".
    match = re.search(r"\b(\d{4}[-/]\d{1,2}[-/]\d{1,2}|\d{1,2}[-/.]\d{1,2}[-/.]\d{2,4}|\d{1,2}[-/ ]+[A-Za-z]{3,9}[-/ ]+\d{4}|\d{1,2}\s+[A-Za-z]{3,9}\s+\d{4}|[A-Za-z]{3,9}\s+\d{1,2},?\s+\d{4})\b", value)
    candidate = match.group(1) if match else value
    for fmt in _DATE_FORMATS:
        try:
            return datetime.strptime(candidate, fmt).date().isoformat()
        except ValueError:
            pass
    # ISO date-time and some locale variants.
    try:
        return datetime.fromisoformat(candidate.replace("Z", "+00:00")).date().isoformat()
    except ValueError:
        return None


def _set_value(result: dict, label: str, value: str) -> None:
    key = _label_key(label)
    for field, aliases in _LABELS.items():
        if key in aliases and _clean(value):
            cleaned = _clean(value)
            result[field] = _parse_date(cleaned) if field == "review_date" else cleaned
            if field == "review_date" and not result[field]:
                result.pop(field, None)
            return


def _read_docx_metadata(path: Path, source: str) -> dict:
    result = {"source": source, "title": path.stem}
    try:
        doc = Document(str(path))
        for paragraph in doc.paragraphs:
            if paragraph.text.strip():
                result["title"] = _clean(paragraph.text)[:240]
                break

        # The first table is normally the document-control/review table.
        if doc.tables:
            table = doc.tables[0]
            rows = [[_clean(cell.text.replace("\n", " ")) for cell in row.cells] for row in table.rows]
            for row in rows:
                # Common layout: label/value pairs in one row.
                for i in range(0, len(row) - 1):
                    label = row[i]
                    value = row[i + 1]
                    if _label_key(label) in {a for values in _LABELS.values() for a in values}:
                        _set_value(result, label, value)
                    # Common layout: "Reviewed By: Jane Doe" in a single cell.
                for cell in row:
                    for field, aliases in _LABELS.items():
                        for alias in aliases:
                            pattern = rf"(?i)\b{re.escape(alias)}\s*[:=]\s*(.+)$"
                            match = re.search(pattern, cell)
                            if match:
                                _set_value(result, alias, match.group(1))
            # Header-row layout: labels in one row and values in the next row.
            for i in range(len(rows) - 1):
                headers, values = rows[i], rows[i + 1]
                for col, label in enumerate(headers):
                    if col < len(values):
                        _set_value(result, label, values[col])

        props = doc.core_properties
        if not result.get("author") and props.author:
            result["author"] = _clean(props.author)
    except Exception:
        # A malformed/locked document must not prevent the app from starting.
        pass
    return result


def load_document_metadata() -> dict[str, dict]:
    """Return source -> metadata. Cache is invalidated per file using mtime and size."""
    try:
        cached = json.loads(CACHE_PATH.read_text(encoding="utf-8"))
    except (OSError, ValueError, TypeError):
        cached = {}
    cached_files = cached.get("files", {}) if isinstance(cached, dict) else {}
    updated_files: dict[str, dict] = {}
    result: dict[str, dict] = {}

    if not DOCUMENTS_DIR.exists():
        return result

    for path in DOCUMENTS_DIR.rglob("*"):
        if not path.is_file() or path.suffix.lower() not in SUPPORTED_DOCX:
            continue
        try:
            source = path.relative_to(DOCUMENTS_DIR).as_posix()
            stat = path.stat()
            signature = {"mtime_ns": stat.st_mtime_ns, "size": stat.st_size}
            old = cached_files.get(source, {})
            if old.get("mtime_ns") == signature["mtime_ns"] and old.get("size") == signature["size"] and old.get("metadata"):
                metadata = old["metadata"]
            else:
                metadata = _read_docx_metadata(path, source)
            updated_files[source] = {**signature, "metadata": metadata}
            result[source] = metadata
        except OSError:
            continue

    try:
        CACHE_PATH.write_text(json.dumps({"files": updated_files}, ensure_ascii=False, indent=2), encoding="utf-8")
    except OSError:
        pass
    return result


def normalize_family(value: str) -> str:
    """Normalize obvious version/revision words without claiming unrelated docs match."""
    value = Path(str(value or "")).stem.lower().replace("_", " ").replace("-", " ")
    value = re.sub(r"\b(v|ver|version|rev|revision|updated|update|latest|final|draft|copy|new)\s*[-_. ]*\d+(?:[._-]\d+)*\b", " ", value)
    value = re.sub(r"\b(20\d{2}[-_. ]?\d{0,2}[-_. ]?\d{0,2}|\d{1,2}[-_. ]\d{1,2}[-_. ]20\d{2})\b", " ", value)
    value = re.sub(r"\b(srs|software requirements specification|requirements specification|document)\b", " ", value)
    tokens = re.findall(r"[a-z0-9]+", value)
    return " ".join(token for token in tokens if token not in {"updated", "latest", "final", "old", "new", "rev", "revision", "version"})
