import tempfile
import unittest
from pathlib import Path

from docx import Document
from document_metadata import _parse_date, _read_docx_metadata, normalize_family


class DocumentMetadataTests(unittest.TestCase):
    def test_extracts_review_table_header_row(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "SRS_ServiceA_v2.docx"
            doc = Document()
            doc.add_paragraph("SRS Service A")
            table = doc.add_table(rows=2, cols=3)
            for cell, value in zip(table.rows[0].cells, ["Reviewed By", "Author", "Date"]):
                cell.text = value
            for cell, value in zip(table.rows[1].cells, ["Jane Reviewer", "Alex Author", "22-Oct-2026"]):
                cell.text = value
            doc.save(path)
            result = _read_docx_metadata(path, path.name)
            self.assertEqual(result["reviewed_by"], "Jane Reviewer")
            self.assertEqual(result["author"], "Alex Author")
            self.assertEqual(result["review_date"], "2026-10-22")
            self.assertEqual(result["title"], "SRS Service A")

    def test_parse_date_variants(self):
        self.assertEqual(_parse_date("Date: 22/10/2026"), "2026-10-22")
        self.assertEqual(_parse_date("22 October 2026"), "2026-10-22")
        self.assertIsNone(_parse_date("date unknown"))

    def test_normalizes_obvious_filename_revision_suffixes(self):
        self.assertEqual(normalize_family("SRS_ServiceA_v2_Updated.docx"), "servicea")
        self.assertEqual(normalize_family("SRS Service A Revision 3.docx"), "service a")


if __name__ == "__main__":
    unittest.main()
