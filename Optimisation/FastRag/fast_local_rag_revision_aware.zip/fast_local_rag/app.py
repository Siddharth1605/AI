import time
import threading
import os
import requests
from flask import Flask, jsonify, render_template, request

from config import OLLAMA_URL, CHAT_MODEL, MAX_NEW_TOKENS, OLLAMA_KEEP_ALIVE
from retrieval import HybridRetriever

app = Flask(__name__)

SYSTEM = """You are an engineering knowledge assistant. Answer only from the supplied evidence passages.
Cite every material factual claim using [Source: relative/path, chunk N]. Never invent configuration
values, steps, owners, dates, or behavior. If the evidence does not support an answer, say exactly:
"I couldn't find enough evidence in the indexed documents."

Each passage may include document metadata such as title, Reviewed By, Author, and Review Date.
For ordinary questions, prefer the newest reviewed passage when it is clearly a revision of the same
requirement or document. A newer date is a freshness signal, not proof that unrelated documents are
superseded. Do not combine conflicting values from different revisions as if both are current. If
revision identity is unclear or relevant passages conflict, state the conflict, cite both sources, and
say the documents do not establish which one is authoritative. For explicit history/comparison
questions, preserve the differences between versions instead of suppressing older evidence.
Keep answers concise and specific; do not add generic background that is not in the evidence."""

_retriever = None
_retriever_lock = threading.Lock()


def get_retriever():
    global _retriever
    if _retriever is None:
        with _retriever_lock:
            if _retriever is None:
                _retriever = HybridRetriever()
    return _retriever


def run_rag(question):
    """Same retrieval and generation flow as the original ask.py."""
    start = time.perf_counter()
    retriever = get_retriever()
    retrieved = retriever.search(question)
    retrieval_end = time.perf_counter()

    if not retrieved.get('results'):
        return {
            'answer': "I couldn't find enough evidence in the indexed documents.",
            'sources': [],
            'candidate_count': retrieved.get('candidate_count', 0),
            'timings': retrieved.get('timings', {}),
            'retrieval_seconds': retrieval_end - start,
            'generation_seconds': 0,
            'total_seconds': time.perf_counter() - start,
        }

    passages = []
    for n, item in enumerate(retrieved['results'], 1):
        meta = item.get('meta') or {}
        revision = []
        if meta.get('title'):
            revision.append(f"Title: {meta['title']}")
        if meta.get('review_date'):
            revision.append(f"Review Date: {meta['review_date']}")
        if meta.get('reviewed_by'):
            revision.append(f"Reviewed By: {meta['reviewed_by']}")
        if meta.get('author'):
            revision.append(f"Author: {meta['author']}")
        revision_text = (" | " + " | ".join(revision)) if revision else ""
        passages.append(
            f"[PASSAGE {n} | Source: {meta.get('source', 'unknown')} | "
            f"chunk {meta.get('chunk', '?')}{revision_text}]\n{item.get('text', '')}"
        )
    context = '\n\n---\n\n'.join(passages)
    prompt = (
        f'Question:\n{question}\n\nEvidence passages:\n{context}\n\n'
        'Answer from this evidence only and cite sources.'
    )

    response = requests.post(
        f'{OLLAMA_URL}/api/chat',
        json={
            'model': CHAT_MODEL,
            'stream': False,
            'keep_alive': OLLAMA_KEEP_ALIVE,
            'messages': [
                {'role': 'system', 'content': SYSTEM},
                {'role': 'user', 'content': prompt},
            ],
            'options': {'num_predict': MAX_NEW_TOKENS, 'temperature': 0.1},
        },
        timeout=180,
    )
    response.raise_for_status()
    payload = response.json()
    end = time.perf_counter()

    sources = []
    seen = set()
    for item in retrieved['results']:
        meta = item.get('meta') or {}
        key = (meta.get('source', 'unknown'), meta.get('chunk', '?'))
        if key not in seen:
            seen.add(key)
            sources.append({'source': key[0], 'chunk': key[1], 'review_date': meta.get('review_date'), 'reviewed_by': meta.get('reviewed_by'), 'author': meta.get('author'), 'title': meta.get('title')})

    return {
        'answer': payload.get('message', {}).get('content', '').strip(),
        'sources': sources,
        'retrieved_count': len(retrieved['results']),
        'candidate_count': retrieved.get('candidate_count', 0),
        'timings': {k: round(v, 3) for k, v in retrieved.get('timings', {}).items()},
        'retrieval_seconds': round(retrieval_end - start, 3),
        'generation_seconds': round(end - retrieval_end, 3),
        'total_seconds': round(end - start, 3),
        'prompt_tokens': payload.get('prompt_eval_count'),
        'generated_tokens': payload.get('eval_count'),
    }


@app.get('/')
def index():
    return render_template('index.html', model=CHAT_MODEL)


@app.get('/api/health')
def health():
    try:
        retriever = get_retriever()
        return jsonify({'ok': True, 'model': CHAT_MODEL, 'chunks': retriever.collection.count()})
    except Exception as exc:
        return jsonify({'ok': False, 'error': str(exc)}), 503


@app.post('/api/chat')
def chat():
    body = request.get_json(silent=True) or {}
    question = str(body.get('message', '')).strip()
    if not question:
        return jsonify({'error': 'Please enter a question.'}), 400
    if len(question) > 4000:
        return jsonify({'error': 'Question is too long (maximum 4000 characters).'}), 400
    try:
        return jsonify(run_rag(question))
    except requests.RequestException as exc:
        return jsonify({
            'error': f'Could not reach Ollama at {OLLAMA_URL}. Check that Ollama is running and the model is available.',
            'details': str(exc),
        }), 503
    except Exception as exc:
        return jsonify({'error': str(exc)}), 500


if __name__ == '__main__':
    # Development server for local use only. Do not expose this debug server to the internet.
    app.run(host=os.getenv('RAG_HOST', '0.0.0.0'), port=int(os.getenv('RAG_PORT', '5000')), debug=False)
