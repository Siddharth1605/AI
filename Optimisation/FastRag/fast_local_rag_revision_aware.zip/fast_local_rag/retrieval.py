"""Fast hybrid retrieval with duplicate suppression and review-date-aware evidence selection.

The existing Chroma collection is read-only here: no embeddings are regenerated and
 document_ingest.py does not need to be rerun.
"""
from __future__ import annotations

import hashlib
import re
import time
from datetime import date

import chromadb
import requests
from rank_bm25 import BM25Okapi

from config import (
    CHROMA_DIR, COLLECTION_NAME, DOCUMENTS_DIR, OLLAMA_URL, EMBED_MODEL,
    VECTOR_CANDIDATES, BM25_CANDIDATES, FINAL_CONTEXT_CHUNKS, MAX_CONTEXT_CHARS,
)
from document_metadata import load_document_metadata, normalize_family

_STOP_WORDS = {
    "a", "an", "and", "are", "as", "at", "be", "by", "for", "from", "how",
    "in", "is", "it", "of", "on", "or", "the", "to", "was", "were", "what",
    "when", "where", "which", "who", "why", "with", "does", "do", "can", "could",
    "should", "would", "please", "tell", "me", "about", "explain", "give",
}
_HISTORICAL_RE = re.compile(
    r"\b(previous|previously|older version|old version|historical|history|before|"
    r"what changed|difference between|compare versions|compared with|as of|superseded)\b",
    re.I,
)


def tokenize(text):
    return re.findall(r"[a-zA-Z0-9_./:-]+", text.lower())


def _normal_text(text: str) -> str:
    return " ".join(tokenize(text))


def _text_hash(text: str) -> str:
    return hashlib.sha1(_normal_text(text).encode("utf-8", errors="ignore")).hexdigest()


def _token_similarity(left: str, right: str) -> float:
    a, b = set(tokenize(left)), set(tokenize(right))
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


def _review_date(row):
    value = ((row.get("meta") or {}).get("review_date") or "").strip()
    try:
        return date.fromisoformat(value)
    except (ValueError, TypeError):
        return None


def _is_historical_query(question: str) -> bool:
    return bool(_HISTORICAL_RE.search(question or ""))


def embed(text):
    response = requests.post(
        f"{OLLAMA_URL}/api/embeddings",
        json={"model": EMBED_MODEL, "prompt": text},
        timeout=120,
    )
    response.raise_for_status()
    return response.json()["embedding"]


class HybridRetriever:
    def __init__(self):
        client = chromadb.PersistentClient(path=str(CHROMA_DIR))
        self.collection = client.get_collection(COLLECTION_NAME)
        data = self.collection.get(include=["documents", "metadatas"])
        self.ids = data["ids"]
        self.docs = data["documents"] or []
        self.metas = data["metadatas"] or [{} for _ in self.docs]
        self.bm25 = BM25Okapi([tokenize(d or "") for d in self.docs]) if self.docs else None

        # Read only the lightweight review table metadata from source DOCX files.
        # This does not touch Chroma or call the embedding model.
        self.document_metadata = load_document_metadata()
        self._metadata_by_casefold = {key.replace("\\", "/").casefold(): value
                                      for key, value in self.document_metadata.items()}

    def _enrich(self, row):
        row = dict(row)
        meta = dict(row.get("meta") or {})
        source = str(meta.get("source", "")).replace("\\", "/")
        doc_info = self.document_metadata.get(source) or self._metadata_by_casefold.get(source.casefold()) or {}
        for key in ("reviewed_by", "author", "review_date", "title"):
            if doc_info.get(key):
                meta[key] = doc_info[key]
        title_family = normalize_family(doc_info.get("title") or "")
        source_family = normalize_family(source)
        meta["family_key"] = title_family if len(title_family.split()) >= 2 else source_family
        row["meta"] = meta
        row["normalized_hash"] = _text_hash(row.get("text", ""))
        return row

    def _deduplicate(self, rows, historical: bool):
        """Collapse duplicate evidence so repeated SRS copies cannot crowd out other sources.

        Exact duplicates collapse even without revision metadata. Near-duplicates are
        replaced by the newer reviewed version only when both dates are known. In a
        historical/compare query, revision evidence is retained instead.
        """
        kept = []
        for candidate in rows:
            duplicate_index = None
            duplicate_similarity = 0.0
            for index, existing in enumerate(kept):
                if candidate["id"] == existing["id"]:
                    duplicate_index = index
                    duplicate_similarity = 1.0
                    break
                if candidate.get("normalized_hash") == existing.get("normalized_hash"):
                    duplicate_index = index
                    duplicate_similarity = 1.0
                    break
                if not historical:
                    similarity = _token_similarity(candidate.get("text", ""), existing.get("text", ""))
                    cdate, edate = _review_date(candidate), _review_date(existing)
                    # Avoid merging different content without dates. With known review dates,
                    # near-identical chunks from older SRS revisions are treated as duplicates.
                    same_family = bool(
                        (candidate.get("meta") or {}).get("family_key")
                        and (candidate.get("meta") or {}).get("family_key")
                        == (existing.get("meta") or {}).get("family_key")
                    )
                    if ((similarity >= 0.78) or (same_family and similarity >= 0.58)) and cdate and edate and cdate != edate:
                        duplicate_index = index
                        duplicate_similarity = similarity
                        break
            if duplicate_index is None:
                kept.append(candidate)
                continue

            existing = kept[duplicate_index]
            exact = duplicate_similarity >= 0.999
            if historical and not exact:
                kept.append(candidate)
                continue
            cdate, edate = _review_date(candidate), _review_date(existing)
            # Exact copies: prefer a dated copy over an undated copy, then the newer date.
            # Near copies: replacement only happens when both dates are known (above).
            replace = bool(cdate and (not edate or cdate > edate))
            if replace:
                # Preserve the stronger retrieval rank while using the fresher evidence.
                candidate["rrf"] = max(candidate.get("rrf", 0), existing.get("rrf", 0))
                kept[duplicate_index] = candidate
        return kept

    def search(self, question):
        started = time.perf_counter()
        if not self.docs:
            return {"results": [], "timings": {"total_retrieval": 0.0}, "candidate_count": 0}

        timings = {}
        historical = _is_historical_query(question)
        t = time.perf_counter()
        total = self.collection.count()
        vector_limit = min(max(VECTOR_CANDIDATES * 3, VECTOR_CANDIDATES), total)
        vector = self.collection.query(
            query_embeddings=[embed(question)],
            n_results=vector_limit,
            include=["documents", "metadatas", "distances"],
        )
        vector_rows = []
        ids = (vector.get("ids") or [[]])[0]
        documents = (vector.get("documents") or [[]])[0]
        metadatas = (vector.get("metadatas") or [[]])[0]
        distances = (vector.get("distances") or [[]])[0]
        for rank, (rid, doc, meta, dist) in enumerate(zip(ids, documents, metadatas, distances), 1):
            vector_rows.append({"id": rid, "text": doc or "", "meta": meta or {},
                                "vector_rank": rank, "distance": float(dist) if dist is not None else None})
        timings["vector_search_and_embedding"] = time.perf_counter() - t

        t = time.perf_counter()
        scores = self.bm25.get_scores(tokenize(question)) if self.bm25 else []
        idxs = sorted(range(len(scores)), key=lambda i: scores[i], reverse=True)
        keyword_rows = []
        seen_texts = set()
        for i in idxs:
            if scores[i] <= 0:
                break
            text_hash = _text_hash(self.docs[i] or "")
            if text_hash in seen_texts:
                continue
            seen_texts.add(text_hash)
            keyword_rows.append({"id": self.ids[i], "text": self.docs[i] or "",
                                 "meta": self.metas[i] or {}, "bm25_rank": len(keyword_rows) + 1,
                                 "bm25_score": float(scores[i])})
            if len(keyword_rows) >= BM25_CANDIDATES:
                break
        timings["bm25_search"] = time.perf_counter() - t

        t = time.perf_counter()
        merged = {}
        for row in vector_rows:
            merged[row["id"]] = dict(row, rrf=1.0 / (60 + row["vector_rank"]))
        for row in keyword_rows:
            if row["id"] not in merged:
                merged[row["id"]] = dict(row, rrf=0.0)
            merged[row["id"]]["rrf"] += 1.0 / (60 + row["bm25_rank"])
            merged[row["id"]]["bm25_score"] = row["bm25_score"]

        fused = [self._enrich(row) for row in merged.values()]
        fused.sort(key=lambda row: (row.get("rrf", 0.0), _review_date(row) or date.min), reverse=True)
        raw_candidate_count = len(fused)
        deduped = self._deduplicate(fused, historical=historical)
        # Prevent one long SRS or repeated revision family from consuming the full context.
        results, chars, source_counts = [], 0, {}
        per_source_limit = 3
        for item in deduped:
            meta = item.get("meta") or {}
            source = str(meta.get("source", "unknown"))
            if source_counts.get(source, 0) >= per_source_limit:
                continue
            length = len(item.get("text", ""))
            if chars + length > MAX_CONTEXT_CHARS and results:
                continue
            results.append(item)
            chars += length
            source_counts[source] = source_counts.get(source, 0) + 1
            if len(results) >= FINAL_CONTEXT_CHUNKS:
                break
        timings["rank_fusion_dedup_and_selection"] = time.perf_counter() - t
        timings["total_retrieval"] = time.perf_counter() - started
        return {
            "results": results,
            "timings": timings,
            "candidate_count": raw_candidate_count,
            "deduplicated_count": len(deduped),
            "historical_query": historical,
        }
