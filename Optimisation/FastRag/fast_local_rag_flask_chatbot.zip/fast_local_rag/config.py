from pathlib import Path
import os

BASE_DIR = Path(__file__).resolve().parent
DOCUMENTS_DIR = Path(os.getenv('RAG_DOCUMENTS_DIR', str(BASE_DIR / 'documents')))
CHROMA_DIR = Path(os.getenv('RAG_CHROMA_DIR', str(BASE_DIR / 'chroma_db')))
COLLECTION_NAME = os.getenv('RAG_COLLECTION_NAME', 'engineering_knowledge_v2')

OLLAMA_URL = os.getenv('OLLAMA_URL', 'http://localhost:11434')
CHAT_MODEL = os.getenv('RAG_CHAT_MODEL', 'gemma3:latest')
EMBED_MODEL = os.getenv('RAG_EMBED_MODEL', 'nomic-embed-text')

CHUNK_CHARS = 1800
CHUNK_OVERLAP_CHARS = 220
VECTOR_CANDIDATES = 12
BM25_CANDIDATES = 12
FINAL_CONTEXT_CHUNKS = 5
MAX_CONTEXT_CHARS = 8500
MAX_NEW_TOKENS = 256
OLLAMA_KEEP_ALIVE = '10m'
