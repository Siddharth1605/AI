"""One-time ingestion for DOCX, TXT, MD, LOG and CSV documents."""
import hashlib
import re
from pathlib import Path
import requests
from docx import Document
import chromadb
from config import DOCUMENTS_DIR, CHROMA_DIR, COLLECTION_NAME, OLLAMA_URL, EMBED_MODEL, CHUNK_CHARS, CHUNK_OVERLAP_CHARS

SUPPORTED = {'.docx', '.txt', '.md', '.log', '.csv'}

def read_docx(path: Path) -> str:
    doc = Document(str(path))
    parts = [p.text.strip() for p in doc.paragraphs if p.text.strip()]
    for table in doc.tables:
        for row in table.rows:
            vals = [cell.text.strip().replace('\n', ' ') for cell in row.cells]
            if any(vals):
                parts.append(' | '.join(vals))
    return '\n'.join(parts)

def read_file(path: Path) -> str:
    if path.suffix.lower() == '.docx':
        return read_docx(path)
    if path.suffix.lower() in SUPPORTED:
        return path.read_text(encoding='utf-8', errors='ignore')
    return ''

def chunk_text(text: str):
    # Split by paragraphs, then pack into bounded chunks with modest overlap.
    paragraphs = [re.sub(r'\s+', ' ', p).strip() for p in text.splitlines() if p.strip()]
    chunks, current = [], ''
    for paragraph in paragraphs:
        while len(paragraph) > CHUNK_CHARS:
            piece, paragraph = paragraph[:CHUNK_CHARS], paragraph[CHUNK_CHARS - CHUNK_OVERLAP_CHARS:]
            if current:
                chunks.append(current)
                current = ''
            chunks.append(piece)
        if not current:
            current = paragraph
        elif len(current) + len(paragraph) + 1 <= CHUNK_CHARS:
            current += '\n' + paragraph
        else:
            chunks.append(current)
            current = (current[-CHUNK_OVERLAP_CHARS:] + '\n' + paragraph).strip() if CHUNK_OVERLAP_CHARS else paragraph
    if current:
        chunks.append(current)
    return chunks

def embed(text: str):
    response = requests.post(f'{OLLAMA_URL}/api/embeddings', json={'model': EMBED_MODEL, 'prompt': text}, timeout=180)
    response.raise_for_status()
    return response.json()['embedding']

def main():
    if not DOCUMENTS_DIR.exists():
        raise SystemExit(f'Create {DOCUMENTS_DIR} and copy documents into it first.')
    client = chromadb.PersistentClient(path=str(CHROMA_DIR))
    collection = client.get_or_create_collection(COLLECTION_NAME, metadata={'hnsw:space': 'cosine'})
    paths = sorted(p for p in DOCUMENTS_DIR.rglob('*') if p.is_file())
    file_count, chunk_count = 0, 0
    skipped = []
    for path in paths:
        text = read_file(path)
        if not text.strip():
            if path.suffix.lower() not in SUPPORTED:
                skipped.append(path.relative_to(DOCUMENTS_DIR).as_posix())
            continue
        chunks = chunk_text(text)
        ids, docs, metas, vectors = [], [], [], []
        rel = path.relative_to(DOCUMENTS_DIR).as_posix()
        for i, chunk in enumerate(chunks):
            ids.append(hashlib.sha1(f'{rel}|{i}|{chunk}'.encode('utf-8')).hexdigest())
            docs.append(chunk)
            metas.append({'source': rel, 'chunk': i, 'file_type': path.suffix.lower()})
            vectors.append(embed(chunk))
        collection.upsert(ids=ids, documents=docs, metadatas=metas, embeddings=vectors)
        file_count += 1
        chunk_count += len(chunks)
        print(f'[OK] {rel}: {len(chunks)} chunks')
    print(f'Finished: {file_count} files, {chunk_count} chunks added/updated; collection now has {collection.count()} chunks.')
    if skipped:
        print('Skipped unsupported file types (add a parser if needed):')
        for name in skipped[:50]: print(' -', name)

if __name__ == '__main__':
    main()
