const form = document.getElementById('chat-form');
const input = document.getElementById('message');
const sendButton = document.getElementById('send');
const log = document.getElementById('chat-log');
const welcome = document.getElementById('welcome');
const statusEl = document.getElementById('status');

function scrollBottom(){ log.scrollTop = log.scrollHeight; }
function addMessage(role, text, extra={}) {
  if (welcome) welcome.remove();
  const row = document.createElement('div'); row.className = 'message-row';
  const avatar = document.createElement('div'); avatar.className = 'avatar ' + (role === 'user' ? 'user' : 'bot'); avatar.textContent = role === 'user' ? 'Y' : 'K';
  const content = document.createElement('div'); content.className = 'message-content';
  const label = document.createElement('div'); label.className = 'message-label'; label.textContent = role === 'user' ? 'You' : 'Knowledge Assistant';
  const bubble = document.createElement('div'); bubble.className = 'bubble ' + (role === 'user' ? 'user-bubble' : 'assistant-bubble'); bubble.textContent = text;
  content.append(label, bubble);
  if (role !== 'user' && extra.sources && extra.sources.length) {
    const sources = document.createElement('div'); sources.className = 'sources';
    const title = document.createElement('div'); title.className = 'sources-title'; title.textContent = 'Retrieved sources'; sources.appendChild(title);
    extra.sources.forEach(s => { const chip = document.createElement('span'); chip.className='source-chip'; chip.textContent = `${s.source} · chunk ${s.chunk}`; sources.appendChild(chip); });
    content.appendChild(sources);
  }
  if (role !== 'user' && extra.total_seconds !== undefined) {
    const metrics = document.createElement('div'); metrics.className='metrics';
    metrics.textContent = `Retrieval ${extra.retrieval_seconds}s · Generation ${extra.generation_seconds}s · Total ${extra.total_seconds}s`;
    content.appendChild(metrics);
  }
  row.append(avatar, content); log.appendChild(row); scrollBottom(); return row;
}
function showTyping(){
  const row=addMessage('assistant','Thinking…');
  row.querySelector('.bubble').classList.add('typing'); return row;
}
async function sendQuestion(question) {
  question = question.trim(); if (!question || sendButton.disabled) return;
  addMessage('user', question); input.value=''; input.style.height='auto'; sendButton.disabled=true;
  const typing=showTyping();
  try {
    const response = await fetch('/api/chat', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({message:question})});
    const data = await response.json();
    typing.remove();
    if (!response.ok) addMessage('assistant', data.error || 'Request failed.');
    else addMessage('assistant', data.answer || 'No answer returned.', data);
  } catch (e) {
    typing.remove(); addMessage('assistant', 'Could not contact the Flask server. Check that it is still running.');
  } finally { sendButton.disabled=false; input.focus(); }
}
form.addEventListener('submit', e => { e.preventDefault(); sendQuestion(input.value); });
input.addEventListener('keydown', e => { if(e.key==='Enter' && !e.shiftKey){e.preventDefault();form.requestSubmit();} });
input.addEventListener('input', () => {input.style.height='auto';input.style.height=Math.min(input.scrollHeight,180)+'px';});
document.querySelectorAll('.suggestion').forEach(b => b.addEventListener('click',()=>sendQuestion(b.textContent)));
document.getElementById('new-chat').addEventListener('click',()=>{log.innerHTML='';const clone=document.createElement('div');clone.className='welcome-card';clone.innerHTML='<div class="welcome-icon">✳</div><h2>What are you trying to find?</h2><p>Ask about services, requirements, configuration, design decisions, or troubleshooting. Answers are grounded in retrieved document passages.</p>';log.appendChild(clone);input.focus();});
fetch('/api/health').then(r=>r.json()).then(d=>{statusEl.textContent=d.ok?`Ready · ${d.chunks} chunks`:'Knowledge base unavailable';}).catch(()=>{statusEl.textContent='Server status unavailable';});
