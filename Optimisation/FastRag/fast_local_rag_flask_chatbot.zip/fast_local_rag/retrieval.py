"""Hybrid retrieval: Chroma semantic search + BM25 + reciprocal-rank fusion."""
import re
import time
import requests
import chromadb
from rank_bm25 import BM25Okapi
from config import CHROMA_DIR, COLLECTION_NAME, OLLAMA_URL, EMBED_MODEL, VECTOR_CANDIDATES, BM25_CANDIDATES, FINAL_CONTEXT_CHUNKS, MAX_CONTEXT_CHARS

def tokenize(text):
    return re.findall(r'[a-zA-Z0-9_./:-]+', text.lower())

def embed(text):
    response = requests.post(f'{OLLAMA_URL}/api/embeddings', json={'model': EMBED_MODEL, 'prompt': text}, timeout=120)
    response.raise_for_status()
    return response.json()['embedding']

class HybridRetriever:
    def __init__(self):
        client = chromadb.PersistentClient(path=str(CHROMA_DIR))
        self.collection = client.get_collection(COLLECTION_NAME)
        data = self.collection.get(include=['documents', 'metadatas'])
        self.ids = data['ids']
        self.docs = data['documents'] or []
        self.metas = data['metadatas'] or [{} for _ in self.docs]
        self.bm25 = BM25Okapi([tokenize(d or '') for d in self.docs]) if self.docs else None

    def search(self, question):
        started = time.perf_counter()
        if not self.docs:
            return {'results': [], 'timings': {'total': 0.0}, 'candidate_count': 0}
        timings = {}
        t = time.perf_counter()
        vector = self.collection.query(
            query_embeddings=[embed(question)],
            n_results=min(VECTOR_CANDIDATES, self.collection.count()),
            include=['documents', 'metadatas', 'distances'],
        )
        vector_rows = []
        for rank, (rid, doc, meta, dist) in enumerate(zip(vector['ids'][0], vector['documents'][0], vector['metadatas'][0], vector['distances'][0]), 1):
            vector_rows.append({'id': rid, 'text': doc or '', 'meta': meta or {}, 'vector_rank': rank, 'distance': dist})
        timings['vector_search_and_embedding'] = time.perf_counter() - t

        t = time.perf_counter()
        scores = self.bm25.get_scores(tokenize(question)) if self.bm25 else []
        idxs = sorted(range(len(scores)), key=lambda i: scores[i], reverse=True)[:BM25_CANDIDATES]
        keyword_rows = [{'id': self.ids[i], 'text': self.docs[i] or '', 'meta': self.metas[i] or {}, 'bm25_rank': rank}
                        for rank, i in enumerate(idxs, 1) if scores[i] > 0]
        timings['bm25_search'] = time.perf_counter() - t

        t = time.perf_counter()
        merged = {}
        for row in vector_rows:
            merged[row['id']] = dict(row, rrf=1.0 / (60 + row['vector_rank']))
        for row in keyword_rows:
            if row['id'] not in merged:
                merged[row['id']] = dict(row, rrf=0.0)
            merged[row['id']]['rrf'] += 1.0 / (60 + row['bm25_rank'])
        fused = sorted(merged.values(), key=lambda x: x['rrf'], reverse=True)
        timings['rank_fusion'] = time.perf_counter() - t

        results, chars = [], 0
        for item in fused:
            length = len(item['text'])
            if chars + length > MAX_CONTEXT_CHARS and results:
                continue
            results.append(item)
            chars += length
            if len(results) >= FINAL_CONTEXT_CHUNKS:
                break
        timings['total_retrieval'] = time.perf_counter() - started
        return {'results': results, 'timings': timings, 'candidate_count': len(fused)}
