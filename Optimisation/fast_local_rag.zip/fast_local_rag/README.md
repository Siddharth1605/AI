# Fast Local Engineering RAG

A clean baseline for local Ollama: DOCX/TXT/MD/LOG/CSV ingestion, ChromaDB semantic retrieval, BM25 keyword retrieval, reciprocal-rank fusion, then one grounded answer-generation call. No agent calls or LLM reranker by default.

## Windows setup

1. Install Ollama and make sure these are available:
   ```powershell
   ollama list
   ollama pull nomic-embed-text
   ```
2. Copy a subset of your documents into `documents\` first. Supported formats: `.docx`, `.txt`, `.md`, `.log`, `.csv`. This starter skips PDFs and old `.doc` files.
3. In this folder:
   ```powershell
   py -m venv .venv
   .\.venv\Scripts\Activate.ps1
   pip install -r requirements.txt
   python document_ingest.py
   python ask.py
   ```

## Important safety note

This uses a separate collection named `engineering_knowledge_v2` and does not overwrite your existing collection. Back up documents and database before experimenting. The script creates embeddings at ingestion time; ingesting 130 MB can take a while, but that is a one-time cost.

## Model

`gemma3:latest` currently resolves to the Gemma 3 4B Q4_K_M variant in the Ollama library, but `latest` can change over time. For reproducible benchmarking, record `ollama list` output and pin `gemma3:4b` in `config.py` or the `RAG_CHAT_MODEL` environment variable.

## Performance and accuracy

The target is under 60 seconds, not a guarantee. We keep only five retrieved chunks and cap context size to avoid processing the whole corpus on every question. The best next optimization depends on the timings printed by `ask.py`.

Create 20–30 questions with known answers. Score factual correctness, whether the correct source was retrieved, unsupported claims, and total time. Do not evaluate performance on only one question.

## Limitations

- Ingestion parser currently supports DOCX/TXT/MD/LOG/CSV only.
- BM25 index is rebuilt in memory at startup. If you have many tens of thousands of chunks, we should persist or replace this component.
- Citations identify file and chunk, not exact page/paragraph.
